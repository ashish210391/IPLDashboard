package io.javabrains.ipldashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IpldashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(IpldashboardApplication.class, args);
	}

}
