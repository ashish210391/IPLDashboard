package io.javabrains.ipldashboard.data;

import java.time.LocalDate;

import org.springframework.batch.item.ItemProcessor;

import io.javabrains.ipldashboard.model.Match;

public class MatchDataProcessor implements ItemProcessor<MatchInput, Match> {
   // private static final Logger logger = LoggerFactory.getLogger(MatchDataProcessor.class);

    @Override
    public Match process(MatchInput input) throws Exception {

        String firstInningTeam = "";
        String secondInningTeam="";

        Match match = new Match();
        match.setId(Integer.parseInt(input.getId()));
        match.setCity(input.getCity());
        match.setSeason(input.getSeason());
        match.setDate(LocalDate.parse(input.getDate()));
        match.setPlayerOfMatch(input.getPlayer_of_match());
        match.setVenue(input.getVenue());

        if ("bat".equals(input.getToss_decision())) {
            firstInningTeam = input.getToss_winner();
            secondInningTeam = input.getToss_winner().equals(input.getTeam1())
             ? input.getTeam2() : input.getTeam1();
        }
        else{
            secondInningTeam=input.getToss_winner();
            firstInningTeam=input.getToss_winner().equals(input.getTeam1()) 
            ? input.getTeam2() : input.getTeam1();
        }

        match.setTeam1(firstInningTeam);
        match.setTeam2(secondInningTeam);
        match.setMatchWinner(input.getWinner());
        match.setTossWinner(input.getToss_winner());
        match.setTossDecision(input.getToss_decision());
        match.setResultMargin(input.getResult_margin());
        match.setResult(input.getResult());
        match.setUmpire1(input.getUmpire1());
        match.setUmpire2(input.getUmpire2());
        
        return match;
    }

}
