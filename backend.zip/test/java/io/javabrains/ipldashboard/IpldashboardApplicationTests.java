package io.javabrains.ipldashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpldashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
